import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.function.Function;
import java.util.stream.Collectors;




public class Main {


    private boolean isPrime(int number) {
        if (number <= 1) {
            return false;
        }
        for (int i = 2; i <= Math.sqrt(number); i++) {
            if (number % i == 0) {
                return false;
            }
        }
        return true;
    }
    public boolean main(String[] args) {
    //Задание 1
        List numbers = new Random()
                .ints(1000, 10, 10000)
                .boxed()
                .collect(Collectors.toList());


        long count = new Random()
                .ints(1000, 10, 10000)
                .filter(this::isPrime)
                .count();



        int sum = new Random()
                .ints(1000, 10, 10000)
                .sum();


        new Random()
                .ints(1000, 10, 10000)
                .forEach(System.out::println);


        Map<Integer, String> numberMap = new Random()
                .ints(1000, 10, 10000)
                .boxed()
                .collect(Collectors.toMap(
                        Function.identity(),
                        number -> "Number: " + number));

        //Задание 2
                List<Country> countries = new ArrayList<>();
        Object million;
        countries.add(new Country("Russia", "Moscow", 144, 17098242));
                countries.add(new Country("USA", "Washington D.C.", 331, 9629091));
                countries.add(new Country("China", "Beijing", 1400, 9640011));
                countries.add(new Country("France", "Paris", 67, 643801));
                countries.add(new Country("Germany", "Berlin", 83, 357022));

                // Запросы с использованием Stream API


                List<Country> filteredCountries = countries.stream()
                        .filter(country -> country.getPopulation() > 100000000)
                        .collect(Collectors.toList());

                System.out.println("Страны с населением больше 100 миллионов:");
                for (Country country : filteredCountries) {
                    System.out.println(country.getName());
                }


                List<Country> sortedCountries = countries.stream()
                        .sorted((c1, c2) -> c2.getArea() - c1.getArea())
                        .collect(Collectors.toList());

                System.out.println("Страны, отсортированные по площади:");
                for (Country country : sortedCountries) {
                    System.out.println(country.getName() + " - " + country.getArea() + " км²");
                }


                List<String> capitals = countries.stream()
                        .map(Country::getCapital)
                        .collect(Collectors.toList());

                System.out.println("Столицы стран:");
                for (String capital : capitals) {
                    System.out.println(capital);
                }
        return false;
    }
        }



